Running frontend

- go to frontend dir
- npm install
- npm run build
- npm start